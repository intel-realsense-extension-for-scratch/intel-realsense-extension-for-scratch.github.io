﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealScratch
{
    public class PXCMPacket
    {
        public static List<Hand> Hands;
        public static List<Face> Faces;
        public static Dictionary<string, int> Expressions;
        public static Dictionary<int, string> gestures = new Dictionary<int, string>();
        public static string[] event_driven_gestures = { "swipe", "tap", "wave" };
        public static bool _talk = false;
        public static string sentence = "";
    }

    public static class Conv
    {
        public static float cY(float org)
        {
            return org * -1.283f + 244.15f;
        }
        public static float cX(float org)
        {
            return org * -1.175f + 298.75f;
        }
    }

    public struct Hand
    {
        public float pos_x, pos_y, pos_z; // Hand position (non-normalized)
        public float roll, pitch, yaw; // Hand rotation (Euler *not* Quaternion)
        public int id;
        public PXCMHandData.BodySideType side;
        public List<Joint> joints;
        public Hand(int i, float x, float y, float z, float r, float p, float ya, PXCMHandData.BodySideType s)
        {
            id = i;
            pos_x = Conv.cX(x);
            pos_y = Conv.cY(y);
            pos_z = z;
            roll = r;
            pitch = p;
            yaw = ya;
            side = s;
            joints = new List<Joint>();
        }
        public override string ToString()
        {
            try
            {
                Console.WriteLine("Returned: " + (PXCMPacket.gestures.ContainsKey(id) ? "\"" + PXCMPacket.gestures[id] + "\"" : "null"));
                return "{" + string.Format("\"id\": {0}, \"position\": [{1}, {2}, {3}], \"rotation\": [{4}, {5}, {6}], \"side\": \"{7}\", \"joints\": {8}, \"gesture\": {9}", id, pos_x, pos_y, pos_z, roll, pitch, yaw, side.ToString(), Joint.Stringify(joints), PXCMPacket.gestures.ContainsKey(id) ? "\"" + PXCMPacket.gestures[id] + "\"" : "null") + "}";
            }
            catch (Exception)
            {
                return "";
            }
            finally
            {
                if (PXCMPacket.gestures.Keys.Contains(id))
                {
                    if (PXCMPacket.event_driven_gestures.Contains(PXCMPacket.gestures[id]))
                    {
                        PXCMPacket.gestures[id] = "none";
                    }
                }
            }
        }
    }

    public struct Face
    {
        public float pos_x, pos_y, pos_z; // Hand position (non-normalized)
        public float roll, pitch, yaw; // Hand rotation (Euler *not* Quaternion)
        public List<Joint> landmarks;
        public Dictionary<string, int> expressions;
        public Face(float x, float y, float z, float r, float p, float ya)
        {
            pos_x = Conv.cX(x);
            pos_y = Conv.cY(y);
            pos_z = z;
            roll = r;
            pitch = p;
            yaw = ya;
            landmarks = new List<Joint>();
            expressions = new Dictionary<string, int>();
        }
        public static string StringifyDict(Dictionary<string, int> exps)
        {
            StringBuilder sb = new StringBuilder("{");
            bool b = true;
            foreach (KeyValuePair<string, int> kvp in exps)
            {
                if (!b) sb.Append(", ");
                else b = false;
                sb.Append("\"" + kvp.Key + "\": " + kvp.Value);
            }
            sb.Append("}");
            return sb.ToString();
        }
        public override string ToString()
        {
            return "{" + string.Format("\"position\": [{0}, {1}, {2}], \"rotation\": [{3}, {4}, {5}], \"landmarks\": {6}, \"expressions\": {7}", pos_x, pos_y, pos_z, roll, pitch, yaw, Joint.Stringify(landmarks), StringifyDict(expressions))
                + "}";
        }
    }

    public struct Joint
    {
        public float pos_x, pos_y, pos_z; // Hand position (non-normalized)
        public float roll, pitch, yaw; // Hand rotation (Euler *not* Quaternion)
        public Joint(float x, float y, float z, float r, float p, float ya)
        {
            pos_x = Conv.cX(x);
            pos_y = Conv.cY(y);
            pos_z = z;
            roll = r;
            pitch = p;
            yaw = ya;
        }
        public static string Stringify(List<Joint> jts)
        {
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < jts.Count; i++)
            {
                if (i != 0) sb.Append(", ");
                sb.Append(jts[i].ToString());
            }
            sb.Append("]");
            return sb.ToString();
        }
        public override string ToString()
        {
            return "{" + string.Format("\"position\": [{0}, {1}, {2}], \"rotation\": [{3}, {4}, {5}]", pos_x, pos_y, pos_z, roll, pitch, yaw)
                + "}";
        }
    }
}
