﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using SimpleWebServer;

namespace RealScratch
{
    public partial class Form1 : Form
    {
        public static bool _closed { get; private set; }
        public static PXCMSession session;
        public static PXCMSession.ImplVersion version;
        public static PXCMSenseManager instance;
        public static PXCMCapture capture;
        public static PXCMCapture.DeviceInfo device;
        public static PXCMAudioSource.DeviceInfo sound_device;
        public static PXCMAudioSource source;
        public static PXCMSpeechRecognition speechRecognition;

        PXCMCapture.Handler deviceChangeHandler;

        WebServer wserver;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _closed = true;
            wserver = new WebServer(HttpProcessing.HandleRequest, "http://localhost:25456/");
            wserver.Run();
            //StartCamera();
            Thread scratchThread = new Thread(() =>
            {
                while (true)
                {
                    if ((DateTime.UtcNow - new DateTime(2000, 1, 1)).TotalMilliseconds - HttpProcessing.last_request_time < 1000)
                    {
                        label2.BeginInvoke(new Action(() =>
                        {
                            label2.Text = "Scratch connected.";
                        }));
                    }
                    else
                    {
                        label2.BeginInvoke(new Action(() =>
                        {
                            label2.Text = "Scratch not connected.";
                        }));
                    }
                    Thread.Sleep(1000);
                }
            });
            scratchThread.IsBackground = true;
            scratchThread.Start();
        }

        void OnDeviceChange()
        {
            PopulateDevice();
        }

        private void PopulateDevice()
        {
            PXCMSession.ImplDesc d = new PXCMSession.ImplDesc
            {
                @group = PXCMSession.ImplGroup.IMPL_GROUP_SENSOR,
                subgroup = PXCMSession.ImplSubgroup.IMPL_SUBGROUP_VIDEO_CAPTURE
            };
            for (int i = 0; ; i++)
            {
                PXCMSession.ImplDesc d1;
                if (session.QueryImpl(d, i, out d1) < pxcmStatus.PXCM_STATUS_NO_ERROR)
                    break;
                if (session.CreateImpl(d1, out capture) < pxcmStatus.PXCM_STATUS_NO_ERROR)
                    continue;
                capture.SubscribeToCaptureCallbacks(deviceChangeHandler);
                for (int j = 0; true; j++)
                {
                    PXCMCapture.DeviceInfo dinfo;
                    if (capture.QueryDeviceInfo(j, out dinfo) < pxcmStatus.PXCM_STATUS_NO_ERROR)
                        continue;
                    device = dinfo;
                    goto SUCCESSFUL_CHOICE;
                }
            }
            SUCCESSFUL_CHOICE: return;
        }

        private void PopulateSoundDevice()
        {
            for (int i = 0; ; i++)
            {
                PXCMAudioSource.DeviceInfo dinfo;
                if (source.QueryDeviceInfo(i, out dinfo) < pxcmStatus.PXCM_STATUS_NO_ERROR)
                    continue;
                if (dinfo == null) continue;
                sound_device = dinfo;
                goto SUCCESSFUL_CHOICE;
            }
            SUCCESSFUL_CHOICE: return;
        }

        private void OnSpeechRecognized (PXCMSpeechRecognition.RecognitionData rec)
        {
            PXCMPacket.sentence = rec.scores[0].sentence;
            PXCMPacket._talk = true;
        }

        private void OnSpeechAlert(PXCMSpeechRecognition.AlertData data)
        {
            Console.WriteLine(data.label.ToString());
        }

        private void StartCamera()
        {
            session = PXCMSession.CreateInstance();
            version = session.QueryVersion();
            instance = session.CreateSenseManager();
            if (session == null || instance == null)
            {
                MessageBox.Show("Failed to create a sense manager. Oops!");
                return;
            }

            // Settings etc.
            deviceChangeHandler = new PXCMCapture.Handler() { onDeviceListChanged = OnDeviceChange };

            // Testing for device, I guess...
            PopulateDevice();
            if (device == null)
            {
                MessageBox.Show("Failed to fetch RealSense device!");
                return;
            }

            // Actually doing cool stuff here!
            // Setting the module

            PXCMSenseManager.Handler handler = new PXCMSenseManager.Handler();

            if (device.model != PXCMCapture.DeviceModel.DEVICE_MODEL_SR300) // Checking the device type. Recommended is DEVICE_MODEL_SR300
            {
                MessageBox.Show("RealScratch works best with SR300. It's recommended to use it, and not " + device.model.ToString());
            }

            pxcmStatus hand_enabling_status = instance.EnableHand();
            pxcmStatus face_enabling_status = instance.EnableFace();

            PXCMFaceModule pxcmFaceModule = instance.QueryFace();
            PXCMFaceData face1 = pxcmFaceModule.CreateOutput();
            int num1 = (int)instance.Init();
            PXCMFaceConfiguration config1 = pxcmFaceModule.CreateActiveConfiguration();
            int num2 = (int)config1.SetTrackingMode(PXCMFaceConfiguration.TrackingModeType.FACE_MODE_COLOR_PLUS_DEPTH);
            config1.strategy = PXCMFaceConfiguration.TrackingStrategyType.STRATEGY_RIGHT_TO_LEFT;
            config1.detection.maxTrackedFaces = 1;
            config1.pose.maxTrackedFaces = 1;
            config1.QueryExpressions().Enable();
            config1.QueryExpressions().EnableAllExpressions();
            config1.pose.isEnabled = true;
            config1.pose.maxTrackedFaces = 1;
            config1.detection.isEnabled = true;
            config1.landmarks.isEnabled = true;
            config1.pose.isEnabled = true;
            int num3 = (int)config1.ApplyChanges();

            PXCMHandModule pxcmHandModule = instance.QueryHand();
            PXCMHandConfiguration config2 = pxcmHandModule.CreateActiveConfiguration();
            int num4 = (int)config2.EnableAllGestures(true);
            int num5 = (int)config2.EnableAllAlerts();
            int num6 = (int)config2.ApplyChanges();
            PXCMHandData hand1 = pxcmHandModule.CreateOutput();

            source = session.CreateAudioSource();
            PopulateSoundDevice();
            if (sound_device != null)
            { 
                if (source == null)
                {
                    MessageBox.Show("Failed to create an audio source!\r\nVoice recognition feature won't be available for use.");
                }
                source.SetVolume(.2f);
                source.SetDevice(sound_device);
                if (session.CreateImpl(out speechRecognition) < pxcmStatus.PXCM_STATUS_NO_ERROR)
                {
                    MessageBox.Show("Failed to create Speech Recognition object. Speech recognition feature will not be available to use");
                    goto NO_SOUND;
                }
                if (speechRecognition.SetDictation() < pxcmStatus.PXCM_STATUS_NO_ERROR)
                {
                    MessageBox.Show("Failed to set speech recognition dictation. Speech recognition feature will not be available to use");
                    goto NO_SOUND;
                }
                PXCMSpeechRecognition.Handler sHandler = new PXCMSpeechRecognition.Handler() { onRecognition = OnSpeechRecognized, onAlert = OnSpeechAlert };
                if (speechRecognition.StartRec(source, sHandler) >= pxcmStatus.PXCM_STATUS_NO_ERROR)
                {
                    Console.WriteLine("Speech recognition successfully enabled");
                }
            }
            NO_SOUND:

            Thread processingThread = new Thread(() =>
            {
                while (!_closed)
                { 
                    if (instance.AcquireFrame(true) >= pxcmStatus.PXCM_STATUS_NO_ERROR)
                    {
                        if (hand1 != null)
                        {
                            hand1.Update();
                        }
                        if (face1 != null)
                        {
                            face1.Update();
                        }
                        int faces = face1.QueryNumberOfDetectedFaces();
                        int hands = hand1.QueryNumberOfHands();

                        List<Hand> _hands = new List<Hand>();
                        for (int i = 0; i < hands; i++)
                        {
                            PXCMHandData.IHand hData1 = null;
                            if (hand1.QueryHandData(PXCMHandData.AccessOrderType.ACCESS_ORDER_BY_ID, i, out hData1) == pxcmStatus.PXCM_STATUS_NO_ERROR)
                            {
                                
                                PXCMHandData.JointData jD;
                                if (hData1.QueryTrackedJoint(PXCMHandData.JointType.JOINT_CENTER, out jD) >= pxcmStatus.PXCM_STATUS_NO_ERROR)
                                {
                                    Hand h = new Hand(hData1.QueryUniqueId(), jD.positionImage.x, jD.positionImage.y, jD.positionWorld.z, QuaternionToRoll(jD.localRotation.x, jD.localRotation.y, jD.localRotation.z, jD.localRotation.w), 0, 0, hData1.QueryBodySide());
                                    PXCMHandData.JointData joint;
                                    for (int j = 0; j < 22; j++)
                                    {
                                        hData1.QueryTrackedJoint((PXCMHandData.JointType)j, out joint);
                                        Joint jj = new Joint(joint.positionImage.x, joint.positionImage.y, joint.positionWorld.z, QuaternionToRoll(joint.localRotation.x, joint.localRotation.y, joint.localRotation.z, joint.localRotation.w), 0, 0);
                                        h.joints.Add(jj);
                                    }
                                    // TODO: Hand gestures
                                    PXCMHandData.GestureData gd = null;
                                    int gest = hand1.QueryFiredGesturesNumber();
                                    lock (PXCMPacket.gestures)
                                    {
                                        int[] k = PXCMPacket.gestures.Keys.ToArray();
                                        foreach (int s in k)
                                        {
                                            if (!PXCMPacket.event_driven_gestures.Contains(PXCMPacket.gestures[s]))
                                            {
                                                PXCMPacket.gestures[s] = "null";
                                            }
                                        }
                                        for (int j = 0; j < gest; j++)
                                        {
                                            hand1.QueryFiredGestureData(j, out gd);
                                            if (gd.name == "tap")
                                                Console.WriteLine("Tap! Current state: " + (PXCMPacket.gestures.ContainsKey(gd.handId) ? PXCMPacket.gestures[gd.handId] : "null"));
                                            if ((PXCMPacket.gestures.ContainsKey(gd.handId) && PXCMPacket.gestures[gd.handId] == "null") || !PXCMPacket.gestures.ContainsKey(gd.handId))
                                            {
                                                PXCMPacket.gestures[gd.handId] = gd.name;
                                                Console.WriteLine("Changed to: " + gd.name);
                                            }
                                        }
                                    }
                                    _hands.Add(h);
                                }
                            }
                        }

                        List<Face> _faces = new List<Face>();
                        for (int i = 0; i < faces; i++)
                        {
                            PXCMFaceData.Face fData1 = face1.QueryFaceByIndex(i);
                            PXCMFaceData.LandmarksData lm = fData1.QueryLandmarks();
                            PXCMFaceData.LandmarkPoint[] pd;
                            PXCMFaceData.PoseData pose = fData1.QueryPose();
                            PXCMFaceData.PoseEulerAngles euler = null;
                            if (pose == null) continue;
                            pose.QueryPoseAngles(out euler);
                            int DEFAULT_LANDMARK_INDEX = 5;
                            lm.QueryPoints(out pd);
                            PXCMFaceData.LandmarkPoint pdd = pd[DEFAULT_LANDMARK_INDEX];
                            Face f = new Face(pdd.image.x, pdd.image.y, pdd.world.z, euler.roll, euler.pitch, euler.yaw);
                            for (int j = 0; j < 78; j++)
                            {
                                Joint jj = new Joint(pd[j].image.x, pd[j].image.y, pd[j].world.z, 0, 0, 0);
                                f.landmarks.Add(jj);
                            }
                            PXCMFaceData.ExpressionsData ed = fData1.QueryExpressions();
                            if (ed != null)
                            {
                                for (int j = 0; j < 22; j++)
                                {
                                    PXCMFaceData.ExpressionsData.FaceExpressionResult res = null;
                                    ed.QueryExpression((PXCMFaceData.ExpressionsData.FaceExpression)j, out res);
                                    f.expressions[((PXCMFaceData.ExpressionsData.FaceExpression)j).ToString()] = res.intensity;
                                }
                            }
                            // TODO: Test facial expressions
                            _faces.Add(f);
                        }

                        //Updating the packet
                        PXCMPacket.Hands = _hands;
                        PXCMPacket.Faces = _faces;

                        // Releasing the frame.
                        // Very important line! Do not remove at any cost!
                        instance.ReleaseFrame(); // I'm serious. This is HIGHLY IMPORTANT!
                    }
                    Thread.Sleep(30);
                }
                if (hand1 != null)
                    hand1.Dispose();
                if (face1 != null)
                    face1.Dispose();
                if (source != null)
                    source.Dispose();
                instance.Close();
                instance.Dispose();
                session.Dispose();
                try
                {
                    label1.BeginInvoke(new Action(() =>
                    {
                        label1.Text = "Camera stopped.";
                    }));
                }
                catch { }
            });
            processingThread.Start();
        }

        public float QuaternionToRoll(float x, float y, float z, float w)
        {
            float num1 = 2f * y;
            float num2 = 2f * z;
            float num3 = num2 * w;
            float num4 = num1 * x;
            float num5 = num1 * y;
            float num6 = num2 * z;
            return (float)Math.Atan2(num4 + (double)num3, 1.0 - num5 - (double)num6);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            _closed = true;
            wserver.Stop();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (_closed)
                try
                {
                    new Thread(() =>
                    {
                        label1.BeginInvoke(new Action(() =>
                        {
                            label1.Text = "Starting camera...";
                        }));
                        _closed = false;
                        StartCamera();
                        label1.BeginInvoke(new Action(() =>
                        {
                            label1.Text = "Camera is working.";
                        }));
                    }).Start();
                }
                catch
                {
                    label1.Text = "Camera error.";
                }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!_closed)
                _closed = true;
        }
    }
}
