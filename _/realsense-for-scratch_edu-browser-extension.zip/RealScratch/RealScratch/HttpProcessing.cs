﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;

namespace RealScratch
{
    class HttpProcessing
    {
        public static double last_request_time = 0;
        public static string HandleRequest(HttpListenerRequest req)
        {
            last_request_time = (DateTime.UtcNow - new DateTime(2000, 1, 1)).TotalMilliseconds;
            if (Form1._closed)
            {
                return "{\"error\": \"NONE\", \"hands\": [], \"faces\": [], \"sentence\": \"\"}";
            }
            try
            {
                StringBuilder sb = new StringBuilder("{\"error\": \"NONE\", \"hands\": [");
                lock (PXCMPacket.Faces) lock (PXCMPacket.Hands)
                    {
                        for (int i = 0; i < PXCMPacket.Hands.Count; i++)
                        {
                            if (i != 0) sb.Append(", ");
                            sb.Append(PXCMPacket.Hands[i].ToString());
                        }
                        sb.Append("], \"faces\": [");
                        for (int i = 0; i < PXCMPacket.Faces.Count; i++)
                        {
                            if (i != 0) sb.Append(", ");
                            sb.Append(PXCMPacket.Faces[i].ToString());
                        }
                        sb.Append("]");
                        if (PXCMPacket._talk)
                        {
                            PXCMPacket._talk = false;
                            sb.Append(", \"sentence\": \"" + PXCMPacket.sentence.Replace("\"", "'") + "\"");
                        }
                        sb.Append("}");
                    }
                return sb.ToString();
            }
            catch
            {
                return "{\"error\": \"NOT_WORKING\"}";
            }
        }
    }
}
